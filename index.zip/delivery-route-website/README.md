# Smart Delivery Route Planner (website)

Flask website that plans the shortest delivery route through many stops (Travelling Salesman Problem) and compares four algorithms: Greedy (Nearest Neighbour), Dynamic Programming (Held-Karp), Branch and Bound, and Brute Force.

**How it works:** the page (`templates/`, `static/`) sends the stops to the Flask backend (`app.py` → `POST /api/solve`). The backend runs the algorithms in `algorithms/tsp.py` and returns each route, its distance and running time, which the page draws on the map.

## Run on your computer
```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Deploy
Any Python host works. The start command is:
```
gunicorn app:app --bind 0.0.0.0:$PORT
```
- **Render:** push this folder to GitHub → New → Web Service → pick the repo. `render.yaml` fills in the settings.
- **Railway / Heroku-style hosts:** the `Procfile` is picked up automatically.
- **PythonAnywhere:** upload the folder, create a Flask web app, point the WSGI file to `from app import app as application`.

## Pages and API
| URL | What it is |
|---|---|
| `/` | Route planner: add stops, pick algorithms, see routes on the map |
| `/benchmark` | Measured performance tables and graphs |
| `POST /api/solve` | Body `{"points":[{"x":..,"y":..}] or [{"lat":..,"lon":..}], "algorithms":["greedy","dp","bnb","brute"]}` |
| `GET /api/samples` | Sample datasets from `data/` |

Exact algorithms are limited by size so the server never hangs: DP up to 18 stops, Branch and Bound up to 14, Brute Force up to 10. Greedy handles up to 2000.

## Other files
- `tests/test_tsp.py` – unit tests (`python tests/test_tsp.py`)
- `benchmark.py` – re-measures performance and redraws the graphs in `results/` (only needed locally, not on the server)
