"""
Smart Delivery Route Planning System - web interface (Flask)

Run:   pip install -r requirements.txt
       python app.py
Open:  http://127.0.0.1:5000
"""
import json
import math
import os
import time

from flask import Flask, jsonify, render_template, request, send_from_directory

from algorithms.tsp import ALGORITHMS, MAX_N, euclidean_matrix

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__)

LABELS = {
    "greedy": "Greedy (Nearest Neighbour)",
    "dp": "Dynamic Programming (Held-Karp)",
    "bnb": "Branch and Bound (LC)",
    "brute": "Brute Force",
}


def latlon_to_km(points):
    """Project latitude/longitude to a flat x/y plane in km (fine for a city)."""
    lat0 = sum(p["lat"] for p in points) / len(points)
    kx = 111.32 * math.cos(math.radians(lat0))
    return [((p["lon"]) * kx, (p["lat"]) * 110.57) for p in points]


def parse_points(payload):
    pts = payload.get("points", [])
    if not isinstance(pts, list) or len(pts) < 2:
        raise ValueError("Add at least 2 locations (the first one is the depot).")
    if "lat" in pts[0]:
        coords = latlon_to_km(pts)
    else:
        coords = [(float(p["x"]), float(p["y"])) for p in pts]
    return coords


def run_one(key, dist):
    n = len(dist)
    if n > MAX_N[key]:
        return {"key": key, "algorithm": LABELS[key], "skipped": True,
                "reason": f"n = {n} is above the practical limit of {MAX_N[key]} for this algorithm"}
    t0 = time.perf_counter()
    res = ALGORITHMS[key](dist)
    ms = (time.perf_counter() - t0) * 1000
    res.update({"key": key, "time_ms": round(ms, 3), "cost": round(res["cost"], 3), "skipped": False})
    return res


@app.route("/")
def index():
    return render_template("index.html", labels=LABELS, max_n=MAX_N)


@app.route("/benchmark")
def benchmark_page():
    path = os.path.join(BASE, "results", "benchmark.json")
    data = None
    if os.path.exists(path):
        with open(path) as f:
            data = json.load(f)
    return render_template("benchmark.html", data=data, labels=LABELS, fact=math.factorial)


@app.route("/results/<path:name>")
def result_file(name):
    return send_from_directory(os.path.join(BASE, "results"), name)


@app.route("/api/samples")
def samples():
    out = {}
    folder = os.path.join(BASE, "data")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".json"):
            with open(os.path.join(folder, name)) as f:
                out[name[:-5]] = json.load(f)
    return jsonify(out)


@app.route("/api/solve", methods=["POST"])
def solve():
    payload = request.get_json(force=True, silent=True) or {}
    if len(payload.get("points", [])) > 2000:
        return jsonify({"error": "At most 2000 locations are allowed."}), 400
    try:
        coords = parse_points(payload)
    except (ValueError, KeyError, TypeError) as e:
        return jsonify({"error": str(e)}), 400
    keys = payload.get("algorithms") or ["greedy"]
    dist = euclidean_matrix(coords)
    results = [run_one(k, dist) for k in keys if k in ALGORITHMS]
    done = [r for r in results if not r["skipped"]]
    best = min((r["cost"] for r in done), default=None)
    for r in done:
        r["gap_pct"] = round((r["cost"] - best) / best * 100, 2) if best else 0.0
    return jsonify({"n": len(coords), "results": results})


if __name__ == "__main__":
    # Local run: python app.py  ->  http://127.0.0.1:5000
    # Hosting platforms set PORT; gunicorn uses "app:app" (see Procfile).
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=os.environ.get("FLASK_DEBUG") == "1")
