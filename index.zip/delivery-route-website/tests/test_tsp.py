"""Unit tests: run with  python -m pytest tests  (or python tests/test_tsp.py)"""
import os, random, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from algorithms.tsp import (brute_force, nearest_neighbour, held_karp,
                            branch_and_bound, euclidean_matrix, route_cost)

EXACT = [held_karp, branch_and_bound]


def valid(route, n):
    return route[0] == 0 and route[-1] == 0 and sorted(route[:-1]) == list(range(n))


def test_textbook_example():
    # Classic 4-city example: optimal tour 0-1-3-2-0 with cost 80
    d = [[0, 10, 15, 20], [10, 0, 35, 25], [15, 35, 0, 30], [20, 25, 30, 0]]
    for f in EXACT + [brute_force]:
        r = f(d)
        assert abs(r["cost"] - 80) < 1e-9, f.__name__
        assert valid(r["route"], 4)


def test_small_cases():
    assert held_karp([[0]])["cost"] == 0
    assert branch_and_bound([[0, 5], [5, 0]])["cost"] == 10


def test_exact_methods_agree_with_brute_force():
    rng = random.Random(42)
    for n in range(3, 9):
        for _ in range(5):
            pts = [(rng.uniform(0, 100), rng.uniform(0, 100)) for _ in range(n)]
            d = euclidean_matrix(pts)
            opt = brute_force(d)["cost"]
            for f in EXACT:
                r = f(d)
                assert abs(r["cost"] - opt) < 1e-6, (f.__name__, n)
                assert abs(route_cost(d, r["route"]) - r["cost"]) < 1e-6
                assert valid(r["route"], n)


def test_asymmetric_matrix():
    rng = random.Random(7)
    n = 7
    d = [[0 if i == j else rng.randint(1, 50) for j in range(n)] for i in range(n)]
    opt = brute_force(d)["cost"]
    for f in EXACT:
        assert abs(f(d)["cost"] - opt) < 1e-9


def test_greedy_is_valid_and_not_better_than_optimal():
    rng = random.Random(1)
    for n in range(3, 10):
        pts = [(rng.random() * 100, rng.random() * 100) for _ in range(n)]
        d = euclidean_matrix(pts)
        g = nearest_neighbour(d)
        assert valid(g["route"], n)
        assert g["cost"] >= held_karp(d)["cost"] - 1e-9


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
