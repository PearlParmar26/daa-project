"""
Performance evaluation of the four TSP algorithms.

Run:  python benchmark.py            (takes a few minutes)
      python benchmark.py --quick    (smaller sizes, ~30 s)

For every input size n, TRIALS random instances (points in a 100 x 100 km
area, fixed seeds so results are reproducible) are solved by every algorithm
that is practical for that size. Average wall-clock time, average route cost
and work counters are written to:

    results/benchmark.json   results/benchmark.csv   results/*.png
"""
import csv
import json
import math
import os
import platform
import random
import statistics
import sys
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from algorithms.tsp import (brute_force, branch_and_bound, euclidean_matrix,
                            held_karp, nearest_neighbour)

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "results")
QUICK = "--quick" in sys.argv
TRIALS = 3 if QUICK else 5

ALGOS = {
    "greedy": ("Greedy (Nearest Neighbour)", nearest_neighbour),
    "dp": ("Dynamic Programming (Held-Karp)", held_karp),
    "bnb": ("Branch and Bound (LC)", branch_and_bound),
    "brute": ("Brute Force", brute_force),
}
SIZES = {
    "greedy": [5, 8, 10, 12, 15, 20, 50, 100, 200, 500, 1000, 2000],
    "dp": [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
    "bnb": [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
    "brute": [5, 6, 7, 8, 9, 10],
}
if QUICK:
    SIZES = {"greedy": [5, 10, 50, 100, 500], "dp": list(range(5, 14)),
             "bnb": list(range(5, 12)), "brute": [5, 6, 7, 8, 9]}

COLORS = {"greedy": "#ff9f1c", "dp": "#3a86ff", "bnb": "#2ec4b6", "brute": "#8a5cf6"}
MARKERS = {"greedy": "o", "dp": "s", "bnb": "^", "brute": "D"}


def instance(n, trial):
    rng = random.Random(1000 * n + trial)
    return euclidean_matrix([(rng.uniform(0, 100), rng.uniform(0, 100)) for _ in range(n)])


def timed(fn, dist):
    t0 = time.perf_counter()
    r = fn(dist)
    return (time.perf_counter() - t0) * 1000, r


def main():
    os.makedirs(OUT, exist_ok=True)
    rows = []
    optimal = {}                         # (n, trial) -> optimal cost
    for key in ["dp", "brute", "bnb", "greedy"]:   # dp first so we know optimum
        label, fn = ALGOS[key]
        for n in SIZES[key]:
            times, costs, work = [], [], []
            gaps = []
            for t in range(TRIALS):
                d = instance(n, t)
                ms, r = timed(fn, d)
                times.append(ms)
                costs.append(r["cost"])
                s = r["stats"]
                work.append(s.get("transitions") or s.get("nodes_expanded")
                            or s.get("routes_checked") or s.get("comparisons") or 0)
                if key == "dp":
                    optimal[(n, t)] = r["cost"]
                elif (n, t) in optimal:
                    gaps.append(max(0.0, (r["cost"] - optimal[(n, t)]) / optimal[(n, t)] * 100))
            row = {
                "algorithm": key, "label": label, "n": n, "trials": TRIALS,
                "time_ms_avg": statistics.mean(times), "time_ms_min": min(times),
                "time_ms_max": max(times), "cost_avg": statistics.mean(costs),
                "work_avg": statistics.mean(work),
                "gap_pct_avg": statistics.mean(gaps) if gaps else None,
                "gap_pct_max": max(gaps) if gaps else None,
            }
            rows.append(row)
            print(f"{label:34s} n={n:5d}  avg {row['time_ms_avg']:11.3f} ms"
                  + (f"  gap {row['gap_pct_avg']:6.2f}%" if gaps else ""))

    meta = {"python": platform.python_version(), "machine": platform.machine(),
            "processor": platform.processor() or platform.machine(),
            "system": platform.system(), "trials_per_size": TRIALS,
            "area": "random points in 100 x 100 km, Euclidean distance",
            "date": time.strftime("%Y-%m-%d")}
    with open(os.path.join(OUT, "benchmark.json"), "w") as f:
        json.dump({"meta": meta, "rows": rows}, f, indent=1)
    with open(os.path.join(OUT, "benchmark.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    make_charts(rows)
    print("\nSaved results to", OUT)


# ---------------------------------------------------------------------------
def style(ax, title, xlabel, ylabel):
    ax.set_title(title, fontsize=12, loc="left", color="#1d2321", pad=10)
    ax.set_xlabel(xlabel, color="#5f6a66")
    ax.set_ylabel(ylabel, color="#5f6a66")
    ax.grid(True, color="#e6e9e5", linewidth=0.8)
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    for s in ["left", "bottom"]:
        ax.spines[s].set_color("#b8c0bb")
    ax.tick_params(colors="#5f6a66")


def series(rows, key, field="time_ms_avg"):
    r = [x for x in rows if x["algorithm"] == key]
    return [x["n"] for x in r], [x[field] for x in r]


def make_charts(rows):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10})

    # 1. Execution time vs input size, all algorithms (log scale)
    fig, ax = plt.subplots(figsize=(8, 4.8), dpi=150)
    for k in ["brute", "bnb", "dp", "greedy"]:
        xs, ys = series(rows, k)
        xs2 = [x for x in xs if x <= 20]
        ys2 = ys[:len(xs2)]
        ax.plot(xs2, ys2, marker=MARKERS[k], color=COLORS[k], lw=2, ms=6, label=ALGOS[k][0])
    ax.set_yscale("log")
    style(ax, "Input size vs execution time (log scale)", "Number of locations (n)", "Average time (ms)")
    ax.legend(frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "time_vs_n_all.png")); plt.close(fig)

    # 2. Greedy: measured time vs theoretical n^2
    fig, ax = plt.subplots(figsize=(8, 4.8), dpi=150)
    xs, ys = series(rows, "greedy")
    c = ys[-1] / xs[-1] ** 2
    ax.plot(xs, ys, marker="o", color=COLORS["greedy"], lw=2, ms=6, label="Measured")
    ax.plot(xs, [c * x * x for x in xs], ls="--", color="#5f6a66", lw=1.5, label="Theoretical  c·n²")
    style(ax, "Greedy (Nearest Neighbour): measured vs O(n²)", "Number of locations (n)", "Average time (ms)")
    ax.legend(frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "greedy_vs_theory.png")); plt.close(fig)

    # 3. DP: measured vs theoretical n^2 2^n
    fig, ax = plt.subplots(figsize=(8, 4.8), dpi=150)
    xs, ys = series(rows, "dp")
    c = ys[-1] / (xs[-1] ** 2 * 2 ** xs[-1])
    ax.plot(xs, ys, marker="s", color=COLORS["dp"], lw=2, ms=6, label="Measured")
    ax.plot(xs, [c * x * x * 2 ** x for x in xs], ls="--", color="#5f6a66", lw=1.5, label="Theoretical  c·n²·2ⁿ")
    ax.set_yscale("log")
    style(ax, "Held-Karp DP: measured vs O(n²·2ⁿ)", "Number of locations (n)", "Average time (ms, log)")
    ax.legend(frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "dp_vs_theory.png")); plt.close(fig)

    # 4. B&B and brute force: work done vs (n-1)!
    fig, ax = plt.subplots(figsize=(8, 4.8), dpi=150)
    xs, ys = series(rows, "bnb", "work_avg")
    ax.plot(xs, ys, marker="^", color=COLORS["bnb"], lw=2, ms=6, label="B&B nodes expanded")
    xb, yb = series(rows, "brute", "work_avg")
    ax.plot(xb, yb, marker="D", color=COLORS["brute"], lw=2, ms=6, label="Brute force routes checked")
    ax.plot(xs, [math.factorial(x - 1) for x in xs], ls="--", color="#5f6a66", lw=1.5, label="(n−1)!  full search space")
    ax.set_yscale("log")
    style(ax, "Search space explored: Branch and Bound vs (n−1)!", "Number of locations (n)", "Count (log scale)")
    ax.legend(frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "bnb_pruning.png")); plt.close(fig)

    # 5. Greedy optimality gap
    fig, ax = plt.subplots(figsize=(8, 4.8), dpi=150)
    r = [x for x in rows if x["algorithm"] == "greedy" and x["gap_pct_avg"] is not None]
    ax.bar([str(x["n"]) for x in r], [x["gap_pct_avg"] for x in r], color=COLORS["greedy"], width=0.6)
    for i, x in enumerate(r):
        ax.text(i, x["gap_pct_avg"] + 0.4, f"{x['gap_pct_avg']:.1f}%", ha="center", fontsize=9, color="#1d2321")
    style(ax, "Greedy route length above optimal (vs Held-Karp)", "Number of locations (n)", "Average extra distance (%)")
    ax.grid(axis="x", visible=False)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "greedy_gap.png")); plt.close(fig)


if __name__ == "__main__":
    main()
