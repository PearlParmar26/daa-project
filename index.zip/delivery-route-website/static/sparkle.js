// Small sparkle burst wherever the page is tapped or clicked.
(function () {
  const SHAPES = ["✦", "✧", "★", "✷", "•"];
  const COLORS = ["#ff6b9a", "#ffd23f", "#3a86ff", "#2ec4b6", "#8a5cf6", "#ff9f1c"];
  document.addEventListener("pointerdown", function (e) {
    const ring = document.createElement("span");
    ring.className = "spark-ring";
    ring.style.left = e.clientX + "px";
    ring.style.top = e.clientY + "px";
    document.body.appendChild(ring);
    setTimeout(() => ring.remove(), 550);

    const count = 9;
    for (let i = 0; i < count; i++) {
      const s = document.createElement("span");
      s.className = "spark";
      s.textContent = SHAPES[Math.floor(Math.random() * SHAPES.length)];
      const angle = (Math.PI * 2 * i) / count + Math.random() * 0.5;
      const dist = 22 + Math.random() * 26;
      s.style.left = e.clientX + "px";
      s.style.top = e.clientY + "px";
      s.style.color = COLORS[i % COLORS.length];
      s.style.fontSize = 10 + Math.random() * 10 + "px";
      s.style.setProperty("--dx", Math.cos(angle) * dist + "px");
      s.style.setProperty("--dy", Math.sin(angle) * dist + "px");
      s.style.setProperty("--rot", (Math.random() * 240 - 120) + "deg");
      document.body.appendChild(s);
      setTimeout(() => s.remove(), 750);
    }
  });
})();
